# Training

[![Watch Video](https://github.com/murtazahassan/Neural-Networks-Self-Driving-Car-Raspberry-Pi/blob/main/Step2-Training/Training%20Steps.png)](https://youtu.be/57SODsvC9PU)
