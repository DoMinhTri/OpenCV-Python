# Neural-Networks-Self-Driving-Car-Raspberry-Pi

[![Watch Video](https://github.com/murtazahassan/Neural-Networks-Self-Driving-Car-Raspberry-Pi/blob/main/Other/Project%20Overview.png)](https://youtu.be/VoBsLc8V0Q0)

